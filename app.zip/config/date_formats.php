<?php

// config/date_formats.php
return [
    'formats' => [
        'Y-m-d' => 'YYYY-MM-DD',
        'd/m/Y' => 'DD/MM/YYYY',
        'm/d/Y' => 'MM/DD/YYYY',
        // Add more date formats as needed
    ],
];




?>