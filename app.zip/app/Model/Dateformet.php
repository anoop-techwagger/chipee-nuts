<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DateFormet extends Model
{
    protected $table = 'date_format';
}

